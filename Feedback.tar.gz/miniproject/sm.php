<?php
func();
?>
<?php
function func(){
echo "hi madrchod";
}

?>
