-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2016 at 12:42 PM
-- Server version: 5.6.28-0ubuntu0.15.10.1
-- PHP Version: 5.6.11-1ubuntu3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miniproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `lab_feedback`
--

CREATE TABLE IF NOT EXISTS `lab_feedback` (
  `course_lab_id` varchar(50) NOT NULL,
  `C1` varchar(50) NOT NULL,
  `C2` varchar(50) NOT NULL,
  `C3` varchar(50) NOT NULL,
  `C4` varchar(50) NOT NULL,
  `C5` varchar(50) NOT NULL,
  `D1` varchar(50) NOT NULL,
  `D2` varchar(50) NOT NULL,
  `D3` varchar(50) NOT NULL,
  `D4` varchar(50) NOT NULL,
  `D5` varchar(50) NOT NULL,
  `E1` varchar(50) NOT NULL,
  `E2` varchar(50) NOT NULL,
  `E3` varchar(50) NOT NULL,
  `E4` varchar(50) NOT NULL,
  `E5` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lab_feedback`
--

INSERT INTO `lab_feedback` (`course_lab_id`, `C1`, `C2`, `C3`, `C4`, `C5`, `D1`, `D2`, `D3`, `D4`, `D5`, `E1`, `E2`, `E3`, `E4`, `E5`) VALUES
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_disagree'),
('CS-351', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree'),
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree'),
('CS-351', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree', 'strongly_disagree'),
('CS-351', 'strongly_disagree', 'disagree', 'disagree', 'disagree', 'neutral', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'agree', 'strongly_agree', 'disagree', 'disagree', 'disagree', 'disagree', 'disagree'),
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree'),
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree'),
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree'),
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree'),
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree'),
('EC-202', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'disagree', 'disagree', 'disagree', 'disagree', 'disagree', 'disagree', 'disagree', 'disagree', 'disagree', 'disagree'),
('CS-351', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree', 'strongly_agree');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
