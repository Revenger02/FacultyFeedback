-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2016 at 12:41 PM
-- Server version: 5.6.28-0ubuntu0.15.10.1
-- PHP Version: 5.6.11-1ubuntu3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miniproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_contain`
--

CREATE TABLE IF NOT EXISTS `course_contain` (
  `course_id` varchar(30) NOT NULL,
  `course_title` varchar(200) NOT NULL,
  `l-t-c` varchar(20) NOT NULL,
  `instructor` varchar(200) NOT NULL,
  `l_t_p_c` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_contain`
--

INSERT INTO `course_contain` (`course_id`, `course_title`, `l-t-c`, `instructor`, `l_t_p_c`) VALUES
('CS-301', 'THEORY OF COMPUTATION', '0-0-1', 'CS-503', '3-0-0-6'),
('CS-302', 'Data Communication', '0-0-1', 'Mr. SUBHASHISH DHAL', '3-0-0-6'),
('CS-320', 'COMPILERS', '1-1-1', 'CS-501', '3-1-0-8'),
('CS-351', 'IT-WORKSHOP III:CLOUD COMPUTING ', '1-0-1', 'CS-502', '1-0-3-5'),
('EC-201', 'Analog Circuits', '1-0-1', 'Mourina Ghosh', '3-1-0-8');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course_contain`
--
ALTER TABLE `course_contain`
  ADD PRIMARY KEY (`course_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
